# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '6ebe5c1fb58e39b85f64a0f4a32ae1f76fdbeabfc8f9915124ee9b4fada424aa039ff52651777bc37bb2cc7e1271ffaa278d07ae29a9366a012f883e9e328e66'